<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Medicare</name>
   <tag></tag>
   <elementGuidId>7a5b37b0-ef96-4ffb-975e-a4a0d51c9ef1</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_medicare</value>
   </webElementProperties>
</WebElementEntity>
